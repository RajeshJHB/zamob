@extends('layouts.app')

@section('title', 'ZAMOBILE HOME')

@section('content')
<div class="bg-white rounded-lg shadow-md p-6">
    <h1 class="text-3xl font-bold">ZAMOBILE HOME</h1>
</div>
@endsection
